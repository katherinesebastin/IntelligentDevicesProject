package middleware_test

import (
	"backend/middleware"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

func makeToken(t *testing.T, secret []byte, claims jwt.MapClaims) string {
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	s, err := token.SignedString(secret)
	if err != nil {
		t.Fatal("failed to sign token:", err)
	}
	return s
}

func TestAuthMiddleware_ValidToken_SetsDeviceID(t *testing.T) {

	middleware.JwtSecret = []byte("testsecret123")

	token := makeToken(t, middleware.JwtSecret, jwt.MapClaims{
		"deviceid": float64(42),
		"exp":      time.Now().Add(time.Hour).Unix(),
	})

	req := httptest.NewRequest("GET", "/", nil)
	req.Header.Set("Authorization", "Bearer "+token)

	w := httptest.NewRecorder()

	var capturedDeviceID int
	next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		val := r.Context().Value(middleware.DeviceIDKey)
		if val == nil {
			t.Fatalf("deviceid missing from context")
		}
		capturedDeviceID = val.(int)
		w.WriteHeader(http.StatusOK)
	})

	handler := middleware.AuthMiddleware(next)
	handler.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected next handler (200), got %d", w.Code)
	}
	if capturedDeviceID != 42 {
		t.Fatalf("expected deviceid=42, got %d", capturedDeviceID)
	}
}
