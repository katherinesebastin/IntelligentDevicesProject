package repository

import (
	"database/sql"
)

type AlertRepository struct {
	DB *sql.DB
}

type ReminderData struct {
	Reminder1     sql.NullTime
	Reminder2     sql.NullTime
	Reminder3     sql.NullTime
}

func NewAlertRepository(db *sql.DB) *AlertRepository {
	return &AlertRepository{DB: db}
}

func (r *AlertRepository) GetReminderData(deviceID int) (*ReminderData, error) {
	row := r.DB.QueryRow(`
        SELECT reminder1, reminder2, reminder3
        FROM devices
        WHERE id = $1
    `, deviceID)

	data := &ReminderData{}
	err := row.Scan(&data.Reminder1, &data.Reminder2, &data.Reminder3)
	return data, err
}

