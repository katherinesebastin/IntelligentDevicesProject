package models

import "time"

type Device struct {
	DeviceID  string
	Password  string
	Reminder1 string
	Reminder2 string
	Reminder3 string
}

type PrototypeDevice struct {
    ID        int64     `db:"id"`          // primary key
    DeviceID  string    `db:"device_id"`   // foreign key to devices.device_id
    EntryDate time.Time `db:"entry_date"`
    Mood      int16     `db:"mood"`
}
