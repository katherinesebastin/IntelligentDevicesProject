package service

import (
	"backend/repository"
	"context"
)

type MoodServiceInterface interface {
	SaveMood(ctx context.Context, mood int, deviceID int) error
}

type MoodService struct {
	Repo *repository.MoodRepository
}

func NewMoodService(repo *repository.MoodRepository) *MoodService {
	return &MoodService{Repo: repo}
}

func (s *MoodService) SaveMood(ctx context.Context, mood int, deviceID int) error {
	return s.Repo.InsertMood(ctx, mood, deviceID)
}
