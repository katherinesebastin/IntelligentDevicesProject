package service

import (
	"time"

	"backend/repository"
)

type AlertServiceInterface interface {
	CheckForAlert(deviceID int) (*AlertResult, error)
}

type AlertService struct {
	Repo *repository.AlertRepository
}

type AlertResult struct {
	Alert     bool `json:"alert"`
	Frequency int  `json:"frequency"`
	Duration  int  `json:"duration"`
}

func NewAlertService(repo *repository.AlertRepository) *AlertService {
	return &AlertService{Repo: repo}
}

func (s *AlertService) CheckForAlert(deviceID int) (*AlertResult, error) {
	data, err := s.Repo.GetReminderData(deviceID)
	if err != nil {
		return nil, err
	}

	now := time.Now()

	reminders := []time.Time{}
	if data.Reminder1.Valid {
		reminders = append(reminders, data.Reminder1.Time)
	}
	if data.Reminder2.Valid {
		reminders = append(reminders, data.Reminder2.Time)
	}
	if data.Reminder3.Valid {
		reminders = append(reminders, data.Reminder3.Time)
	}

	for _, rem := range reminders {
		remTime := time.Date(now.Year(), now.Month(), now.Day(),
			rem.Hour(), rem.Minute(), 0, 0, now.Location())

		if now.After(remTime) && now.Before(remTime.Add(time.Minute)) {

			// println("ALERT TRIGGERED for device", deviceID, "at", now.String(), "for reminder", rem.String())

			return &AlertResult{
				Alert:     true,
				Frequency: 1200,
				Duration:  600,
			}, nil
		}
	}
	// println("no alert triggered")
	return &AlertResult{Alert: false}, nil
}
