package handlers_test

import (
	"backend/handlers"
	"bytes"
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

type mockMoodService struct {
	SaveMoodFunc func(ctx context.Context, mood int, deviceID int) error
}

func (m *mockMoodService) SaveMood(ctx context.Context, mood int, deviceID int) error {
	return m.SaveMoodFunc(ctx, mood, deviceID)
}

func TestHandleMood_Success(t *testing.T) {
	mockService := &mockMoodService{
		SaveMoodFunc: func(ctx context.Context, mood int, deviceID int) error {
			if deviceID != 1 {
				t.Fatalf("expected deviceID=1, got %d", deviceID)
			}
			if mood != 2 {
				t.Fatalf("expected mood=2, got %d", mood)
			}
			return nil
		},
	}

	handler := handlers.NewArduinoHandler(mockService)

	jsonBody := `{"device_id":1,"mood":2}`
	req := httptest.NewRequest(http.MethodPost, "/addMood", bytes.NewBufferString(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	handler.HandleMood(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected status 200, got %d", w.Code)
	}

	if w.Body.String() != "OK" {
		t.Fatalf("expected body 'OK', got %s", w.Body.String())
	}
}

func TestHandleMood_InvalidMood(t *testing.T) {
	mockService := &mockMoodService{}

	handler := handlers.NewArduinoHandler(mockService)

	jsonBody := `{"device_id":1,"mood":5}`
	req := httptest.NewRequest(http.MethodPost, "/addMood", bytes.NewBufferString(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	handler.HandleMood(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected status 400 for invalid mood, got %d", w.Code)
	}
}

func TestHandleMood_InvalidDeviceID(t *testing.T) {
	mockService := &mockMoodService{}

	handler := handlers.NewArduinoHandler(mockService)

	jsonBody := `{"device_id":0,"mood":2}`
	req := httptest.NewRequest(http.MethodPost, "/addMood", bytes.NewBufferString(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	handler.HandleMood(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected status 400 for invalid device_id, got %d", w.Code)
	}
}

func TestHandleMood_ServiceError(t *testing.T) {
	mockService := &mockMoodService{
		SaveMoodFunc: func(ctx context.Context, mood int, deviceID int) error {
			return errors.New("db error")
		},
	}

	handler := handlers.NewArduinoHandler(mockService)

	jsonBody := `{"device_id":1,"mood":2}`
	req := httptest.NewRequest(http.MethodPost, "/addMood", bytes.NewBufferString(jsonBody))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()

	handler.HandleMood(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected status 500 for service error, got %d", w.Code)
	}
}
