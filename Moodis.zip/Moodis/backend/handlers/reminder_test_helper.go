package handlers

var TestValidateAndParseTime = validateAndParseTime
