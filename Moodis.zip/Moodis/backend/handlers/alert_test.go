package handlers_test

import (
	"backend/handlers"
	"backend/service"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestGetAlerts_MissingDeviceID(t *testing.T) {
	mockService := &mockAlertService{}
	handler := handlers.NewAlertHandler(mockService)

	req := httptest.NewRequest("GET", "/alerts", nil)
	w := httptest.NewRecorder()

	handler.GetAlerts(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

func TestGetAlerts_InvalidDeviceID(t *testing.T) {
	mockService := &mockAlertService{}
	handler := handlers.NewAlertHandler(mockService)

	req := httptest.NewRequest("GET", "/alerts?device_id=abc", nil)
	w := httptest.NewRecorder()

	handler.GetAlerts(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

func TestGetAlerts_ServiceError(t *testing.T) {
	mockService := &mockAlertService{
		CheckForAlertFunc: func(deviceID int) (*service.AlertResult, error) {
			return nil, errors.New("fail")
		},
	}
	handler := handlers.NewAlertHandler(mockService)

	req := httptest.NewRequest("GET", "/alerts?device_id=10", nil)
	w := httptest.NewRecorder()

	handler.GetAlerts(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}

func TestGetAlerts_Success(t *testing.T) {
	expected := &service.AlertResult{
		Alert:     true,
		Frequency: 1200,
		Duration:  600,
	}

	mockService := &mockAlertService{
		CheckForAlertFunc: func(deviceID int) (*service.AlertResult, error) {
			if deviceID != 7 {
				t.Fatalf("expected deviceID 7, got %d", deviceID)
			}
			return expected, nil
		},
	}

	handler := handlers.NewAlertHandler(mockService)

	req := httptest.NewRequest("GET", "/alerts?device_id=7", nil)
	w := httptest.NewRecorder()

	handler.GetAlerts(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp service.AlertResult
	json.Unmarshal(w.Body.Bytes(), &resp)

	if resp.Alert != expected.Alert ||
		resp.Frequency != expected.Frequency ||
		resp.Duration != expected.Duration {
		t.Fatalf("unexpected response: %+v", resp)
	}
}
