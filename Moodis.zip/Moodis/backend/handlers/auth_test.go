package handlers_test

import (
	"backend/db"
	"backend/handlers"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/DATA-DOG/go-sqlmock"
)

func TestLoginHandler_InvalidJSON(t *testing.T) {
	req := httptest.NewRequest("POST", "/login", strings.NewReader("not-json"))
	w := httptest.NewRecorder()

	handlers.LoginHandler(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

func TestLoginHandler_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn 

	mock.ExpectQuery("SELECT id, password FROM devices").
		WithArgs("device123").
		WillReturnError(sqlmock.ErrCancelled)

	body := `{"deviceId":"device123","password":"test"}`
	req := httptest.NewRequest("POST", "/login", strings.NewReader(body))
	w := httptest.NewRecorder()

	handlers.LoginHandler(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", w.Code)
	}
}

func TestLoginHandler_InvalidPassword(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	rows := sqlmock.NewRows([]string{"id", "password"}).
		AddRow(10, "correctpass")

	mock.ExpectQuery("SELECT id, password FROM devices").
		WithArgs("device123").
		WillReturnRows(rows)

	body := `{"deviceId":"device123","password":"wrongpass"}`
	req := httptest.NewRequest("POST", "/login", strings.NewReader(body))
	w := httptest.NewRecorder()

	handlers.LoginHandler(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", w.Code)
	}
}

func TestLoginHandler_Success(t *testing.T) {

	os.Setenv("JWT_SECRET", "testsecret")

	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	rows := sqlmock.NewRows([]string{"id", "password"}).
		AddRow(5, "pass123")

	mock.ExpectQuery("SELECT id, password FROM devices").
		WithArgs("device123").
		WillReturnRows(rows)

	body := `{"deviceId":"device123","password":"pass123"}`
	req := httptest.NewRequest("POST", "/login", strings.NewReader(body))
	w := httptest.NewRecorder()

	handlers.LoginHandler(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp map[string]string
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatalf("invalid JSON response: %v", err)
	}

	if _, ok := resp["token"]; !ok {
		t.Fatalf("expected response to contain token")
	}
}
