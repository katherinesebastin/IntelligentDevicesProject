package handlers_test

import (
	"backend/db"
	"backend/handlers"
	"backend/middleware"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
)

func withDeviceID(req *http.Request, id int) *http.Request {
	ctx := context.WithValue(req.Context(), middleware.DeviceIDKey, id)
	return req.WithContext(ctx)
}

func TestTodayHandler_NoRows(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now().Format("2006-01-02")

	mock.ExpectQuery("SELECT AVG").
		WithArgs(today, 15).
		WillReturnRows(sqlmock.NewRows([]string{"avg"})) 

	req := httptest.NewRequest("GET", "/today", nil)
	req = withDeviceID(req, 15)
	w := httptest.NewRecorder()

	handlers.TodayHandler(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)

	if resp["avg"] != nil {
		t.Fatalf("expected avg = nil, got %v", resp["avg"])
	}
}

func TestTodayHandler_HasValue(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now().Format("2006-01-02")

	mock.ExpectQuery("SELECT AVG").
		WithArgs(today, 10).
		WillReturnRows(sqlmock.NewRows([]string{"avg"}).AddRow(2.5))

	req := httptest.NewRequest("GET", "/today", nil)
	req = withDeviceID(req, 10)
	w := httptest.NewRecorder()

	handlers.TodayHandler(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)

	if resp["avg"] != 2.5 {
		t.Fatalf("expected avg=2.5, got %v", resp["avg"])
	}
}

func TestTodayHandler_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now().Format("2006-01-02")

	mock.ExpectQuery("SELECT AVG").
		WithArgs(today, 10).
		WillReturnError(sqlmock.ErrCancelled)

	req := httptest.NewRequest("GET", "/today", nil)
	req = withDeviceID(req, 10)
	w := httptest.NewRecorder()

	handlers.TodayHandler(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}

func TestSevenDaysHandler_Success(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now()
	start := today.AddDate(0, 0, -6)

	rows := sqlmock.NewRows([]string{"entry_date", "avg"}).
		AddRow(start, 1.2).
		AddRow(start.AddDate(0, 0, 1), 2.0)

	mock.ExpectQuery("SELECT entry_date, AVG").
		WithArgs(start.Format("2006-01-02"), today.Format("2006-01-02"), 22).
		WillReturnRows(rows)

	req := httptest.NewRequest("GET", "/7days", nil)
	req = withDeviceID(req, 22)
	w := httptest.NewRecorder()

	handlers.SevenDaysHandler(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp []map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)

	if len(resp) != 2 {
		t.Fatalf("expected 2 rows, got %d", len(resp))
	}
}

func TestSevenDaysHandler_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now()
	start := today.AddDate(0, 0, -6)

	mock.ExpectQuery("SELECT entry_date, AVG").
		WithArgs(start.Format("2006-01-02"), today.Format("2006-01-02"), 22).
		WillReturnError(sqlmock.ErrCancelled)

	req := httptest.NewRequest("GET", "/7days", nil)
	req = withDeviceID(req, 22)
	w := httptest.NewRecorder()

	handlers.SevenDaysHandler(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}

func TestThirtyDaysHandler_Success(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now()
	start := today.AddDate(0, 0, -29)

	rows := sqlmock.NewRows([]string{"entry_date", "avg"}).
		AddRow(start, 1.5).
		AddRow(start.AddDate(0, 0, 1), 2.8)

	mock.ExpectQuery("SELECT entry_date, AVG").
		WithArgs(start.Format("2006-01-02"), today.Format("2006-01-02"), 7).
		WillReturnRows(rows)

	req := httptest.NewRequest("GET", "/30days", nil)
	req = withDeviceID(req, 7)
	w := httptest.NewRecorder()

	handlers.ThirtyDaysHandler(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp []map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)

	if len(resp) != 2 {
		t.Fatalf("expected 2 results, got %d", len(resp))
	}
}

func TestThirtyDaysHandler_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	today := time.Now()
	start := today.AddDate(0, 0, -29)

	mock.ExpectQuery("SELECT entry_date, AVG").
		WithArgs(start.Format("2006-01-02"), today.Format("2006-01-02"), 7).
		WillReturnError(sqlmock.ErrCancelled)

	req := httptest.NewRequest("GET", "/30days", nil)
	req = withDeviceID(req, 7)
	w := httptest.NewRecorder()

	handlers.ThirtyDaysHandler(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}
