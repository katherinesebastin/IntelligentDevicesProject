package handlers

import (
	"backend/service"
	"encoding/json"
	"net/http"
)

type ArduinoHandler struct {
	MoodService service.MoodServiceInterface
}

func NewArduinoHandler(ms service.MoodServiceInterface) *ArduinoHandler {
	return &ArduinoHandler{MoodService: ms}
}

func (h *ArduinoHandler) HandleMood(w http.ResponseWriter, r *http.Request) {
	type MoodRequest struct {
		DeviceID int `json:"device_id"`
		Mood     int `json:"mood"`
	}

	var req MoodRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid JSON", http.StatusBadRequest)
		return
	}

	if req.Mood < 1 || req.Mood > 3 {
		http.Error(w, "invalid mood", http.StatusBadRequest)
		return
	}

	if req.DeviceID <= 0 {
		http.Error(w, "invalid device_id", http.StatusBadRequest)
		return
	}

	if err := h.MoodService.SaveMood(r.Context(), req.Mood, req.DeviceID); err != nil {
		http.Error(w, "database error", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("OK"))
}
