package handlers

import "context"

type MoodServiceAdapter struct {
	SaveMoodFunc func(ctx context.Context, mood int, deviceID int) error
}

func (a *MoodServiceAdapter) SaveMood(ctx context.Context, mood int, deviceID int) error {
	return a.SaveMoodFunc(ctx, mood, deviceID)
}
