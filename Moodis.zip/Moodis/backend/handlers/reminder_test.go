package handlers_test

import (
	"backend/db"
	"backend/handlers"
	"backend/middleware"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
)

func withDeviceIDReminder(req *http.Request, id int) *http.Request {
	ctx := context.WithValue(req.Context(), middleware.DeviceIDKey, id)
	return req.WithContext(ctx)
}

func TestValidateAndParseTime_Nil(t *testing.T) {
	res, err := handlers.TestValidateAndParseTime(nil)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result, got %v", res)
	}
}

func TestValidateAndParseTime_EmptyString(t *testing.T) {
	s := ""
	res, err := handlers.TestValidateAndParseTime(&s)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res != nil {
		t.Fatalf("expected nil result for empty string")
	}
}

func TestValidateAndParseTime_ValidHHMM(t *testing.T) {
	s := "12:34"
	res, err := handlers.TestValidateAndParseTime(&s)
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if res == nil || res.Format("15:04:05") != "12:34:00" {
		t.Fatalf("expected 12:34:00, got %v", res)
	}
}

func TestValidateAndParseTime_InvalidFormat(t *testing.T) {
	s := "badtime"
	_, err := handlers.TestValidateAndParseTime(&s)
	if err == nil {
		t.Fatalf("expected error for invalid time")
	}
}

func TestGetReminders_Success(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	t1 := time.Date(2024, 1, 1, 10, 0, 0, 0, time.UTC)
	t2 := time.Date(2024, 1, 1, 14, 30, 0, 0, time.UTC)

	rows := sqlmock.NewRows([]string{"reminder1", "reminder2", "reminder3"}).
		AddRow(t1, t2, nil)

	mock.ExpectQuery("SELECT reminder1").
		WithArgs(5).
		WillReturnRows(rows)

	req := httptest.NewRequest("GET", "/reminders", nil)
	req = withDeviceIDReminder(req, 5)
	w := httptest.NewRecorder()

	handlers.GetReminders(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	var resp map[string]*string
	json.Unmarshal(w.Body.Bytes(), &resp)

	if resp["reminder1"] == nil || *resp["reminder1"] != "10:00:00" {
		t.Fatalf("invalid reminder1: %v", resp["reminder1"])
	}
	if resp["reminder2"] == nil || *resp["reminder2"] != "14:30:00" {
		t.Fatalf("invalid reminder2: %v", resp["reminder2"])
	}
	if resp["reminder3"] != nil {
		t.Fatalf("expected reminder3 nil")
	}
}

func TestGetReminders_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	mock.ExpectQuery("SELECT reminder1").
		WithArgs(5).
		WillReturnError(sqlmock.ErrCancelled)

	req := httptest.NewRequest("GET", "/reminders", nil)
	req = withDeviceIDReminder(req, 5)
	w := httptest.NewRecorder()

	handlers.GetReminders(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}

func TestUpdateReminders_InvalidJSON(t *testing.T) {
	req := httptest.NewRequest("PUT", "/reminders", strings.NewReader("not-json"))
	req = withDeviceIDReminder(req, 7)
	w := httptest.NewRecorder()

	handlers.UpdateReminders(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

func TestUpdateReminders_InvalidTime(t *testing.T) {
	body := `{"reminder1":"BADTIME"}`
	req := httptest.NewRequest("PUT", "/reminders", strings.NewReader(body))
	req = withDeviceIDReminder(req, 7)
	w := httptest.NewRecorder()

	handlers.UpdateReminders(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("expected 400, got %d", w.Code)
	}
}

func TestUpdateReminders_Success(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	mock.ExpectExec("UPDATE devices").
		WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), 7).
		WillReturnResult(sqlmock.NewResult(1, 1))

	body := `{
		"reminder1":"10:00",
		"reminder2":"14:30:05",
		"reminder3":null
	}`

	req := httptest.NewRequest("PUT", "/reminders", strings.NewReader(body))
	req = withDeviceIDReminder(req, 7)
	w := httptest.NewRecorder()

	handlers.UpdateReminders(w, req)

	if w.Code != http.StatusNoContent {
		t.Fatalf("expected 204, got %d", w.Code)
	}
}

func TestUpdateReminders_DBError(t *testing.T) {
	dbConn, mock, _ := sqlmock.New()
	db.DB = dbConn

	mock.ExpectExec("UPDATE devices").
		WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), 7).
		WillReturnError(sqlmock.ErrCancelled)

	body := `{"reminder1":"10:00"}`
	req := httptest.NewRequest("PUT", "/reminders", strings.NewReader(body))
	req = withDeviceIDReminder(req, 7)
	w := httptest.NewRecorder()

	handlers.UpdateReminders(w, req)

	if w.Code != http.StatusInternalServerError {
		t.Fatalf("expected 500, got %d", w.Code)
	}
}
