package handlers_test

import "backend/service"

type mockAlertService struct {
	CheckForAlertFunc func(deviceID int) (*service.AlertResult, error)
}

func (m *mockAlertService) CheckForAlert(deviceID int) (*service.AlertResult, error) {
	return m.CheckForAlertFunc(deviceID)
}
