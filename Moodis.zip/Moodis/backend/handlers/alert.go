package handlers

import (
	"backend/service"
	"encoding/json"
	"net/http"
	"strconv"
)

type AlertHandler struct {
    AlertService service.AlertServiceInterface
}

func NewAlertHandler(s service.AlertServiceInterface) *AlertHandler {
    return &AlertHandler{AlertService: s}
}

func (h *AlertHandler) GetAlerts(w http.ResponseWriter, r *http.Request) {
	deviceIDStr := r.URL.Query().Get("device_id")
	if deviceIDStr == "" {
		http.Error(w, "device_id is required", http.StatusBadRequest)
		return
	}

	deviceID, err := strconv.Atoi(deviceIDStr)
	if err != nil {
		http.Error(w, "invalid device_id", http.StatusBadRequest)
		return
	}

	result, err := h.AlertService.CheckForAlert(deviceID)
	if err != nil {
		http.Error(w, "Failed to fetch alerts", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}

